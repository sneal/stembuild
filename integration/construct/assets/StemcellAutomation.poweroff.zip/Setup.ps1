echo "mock stemcell automation script executed"
# Sleep some amount of time
Stop-Computer
